import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HotelReservationSystem
{
    private static final String url = "jdbc:mysql://127.0.0.1:3306/HotelMngSys?user=root";
    private static final String username = "root";
    private static final String password = "Sumit@2002";
//connection building using jdbc drivers and scanner class for inputs
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e.getMessage());
        }

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            Scanner scanner = new Scanner(System.in);
//menues at a time of reservation reservation 
            while (true) {
                System.out.println();
                System.out.println(" *HOTEL TRIDENT* ");
                System.out.println("1.  View Rooms ");
                System.out.println("2.  Reserve a room");
                System.out.println("3.  View Reservations");
                System.out.println("4.  Get Room Number");
                System.out.println("5.  Update Reservations");
                System.out.println("6.  Delete Reservations");
                System.out.println("7.  Add New Room ");
                System.out.println("0.  Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
//choice selection and baced on that resp function (p)called
                switch (choice) {
                     case 1 -> viewRooms(connection);
                    case 2 -> reserveRoom(connection, scanner);
                    case 3 -> viewReservations(connection);
                    case 4 -> getRoomNumber(connection, scanner);
                    case 5 -> updateReservation(connection, scanner);
                    case 6 -> deleteReservation(connection, scanner);
                    case 7 -> addNewRoom(connection, scanner);
               
                    case 0 -> {
                        exit();
                        scanner.close();                                                                                                                         
                        return;
                    }
                    default -> System.out.println("Invalid choice. Try again.");
                }
            }

        } catch (SQLException e) {
            System.out.println("Database connection error: " + e.getMessage());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static void addNewRoom(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter new room number: ");
            int roomNumber = scanner.nextInt();
            scanner.nextLine(); 

            System.out.print("Is the room available? (true/false): ");
            boolean isAvailable = scanner.nextBoolean();
            scanner.nextLine(); 

            
            connection.setAutoCommit(false);//manually commit n roolback
            try {
                String sql = "INSERT INTO rooms (room_no, is_available) VALUES (?, ?)";
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setInt(1, roomNumber);
                    ps.setBoolean(2, isAvailable);

                    int affectedRows = ps.executeUpdate();

                    if (affectedRows > 0) {
                        System.out.println("Room " + roomNumber + " added successfully with is_available = " + isAvailable);
                        connection.commit();
                    } else {
                        System.out.println("Failed to add room.");
                        connection.rollback();
                    }
                }
            } catch (SQLException e) {
                connection.rollback();
                if (e.getMessage().contains("Duplicate")) {
                    System.out.println("Room number " + roomNumber + " already exists.");
                } else {
                    System.out.println("Error adding room: " + e.getMessage());
                }
            } finally {
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error in addNewRoom: " + e.getMessage());
        }
    }
//take name roomno cont check room available
    private static void reserveRoom(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter guest name: ");
            scanner.nextLine(); 
            String guestName = scanner.nextLine();

            System.out.print("Enter room number: ");
            int roomNumber = scanner.nextInt();
            scanner.nextLine(); 

            System.out.print("Enter contact number: ");
            String contactNumber = scanner.nextLine();

            String checkSql = "SELECT is_available FROM rooms WHERE room_no = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
                checkStmt.setInt(1, roomNumber);
                ResultSet resultSet = checkStmt.executeQuery();

                if (resultSet.next()) {
                    boolean isAvailable = resultSet.getBoolean("is_available");

                    if (!isAvailable) {
                        System.out.println("Room number " + roomNumber + " is already booked. Please choose a different room.");
                        return;
                    }
                } else {
                    System.out.println("Room number " + roomNumber + " does not exist.");
                    return;
                }
            }

           //insert into
            connection.setAutoCommit(false);
            try {
                String insertSql = "INSERT INTO reservations (cust_name, room_no, contact_no) VALUES (?, ?, ?)";
                try (PreparedStatement insertStmt = connection.prepareStatement(insertSql))
                {
                    insertStmt.setString(1, guestName);
                    insertStmt.setInt(2, roomNumber);
                    insertStmt.setString(3, contactNumber);

                    int affectedRows = insertStmt.executeUpdate();

                    if (affectedRows > 0)
                    {//set room as booked
                        String updateRoomSql = "UPDATE rooms SET is_available = FALSE WHERE room_no = ?";
                        try (PreparedStatement updateRoomStmt = connection.prepareStatement(updateRoomSql))
                        {
                            updateRoomStmt.setInt(1, roomNumber);
                            updateRoomStmt.executeUpdate();
                        }
                        System.out.println("Reservation successful!");
                        connection.commit();
                    } else {
                        System.out.println("Reservation failed.");
                        connection.rollback();
                    }
                }
            } catch (SQLException e) 
            {
                connection.rollback();
                System.out.println("Error reserving room: " + e.getMessage());
            } finally 
            {
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error in reserveRoom: " + e.getMessage());
        }
    }
//select*from reserv
    private static void viewReservations(Connection connection) {
        String sql = "SELECT resv_id, cust_name, room_no, contact_no, resv_date FROM reservations";

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet resultSet = ps.executeQuery()) {

            System.out.println("Current Reservations:");
            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");
            System.out.println("| Reservation ID | Customer         | Room Number   | Contact Number      | Reservation Date        |");
            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");

            while (resultSet.next()) {
                int reservationId = resultSet.getInt("resv_id");
                String guestName = resultSet.getString("cust_name");
                int roomNumber = resultSet.getInt("room_no");
                String contactNumber = resultSet.getString("contact_no");
                String reservationDate = resultSet.getTimestamp("resv_date").toString();

                System.out.printf("| %-14d | %-15s | %-13d | %-20s | %-19s   |\n",
                        reservationId, guestName, roomNumber, contactNumber, reservationDate);
            }

            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");
        } catch (SQLException e) {
            System.out.println("Error viewing reservations: " + e.getMessage());
        }
    }

    private static void getRoomNumber(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter reservation ID: ");
            int reservationId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter guest name: ");
            String guestName = scanner.nextLine();

            String sql = "SELECT room_no FROM reservations WHERE resv_id = ? AND cust_name = ?";

            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, reservationId);
                ps.setString(2, guestName);

                try (ResultSet resultSet = ps.executeQuery()) {
                    if (resultSet.next()) {
                        int roomNumber = resultSet.getInt("room_no");
                        System.out.println("Room number for Reservation ID  " + reservationId +
                                " and Guest  Name :' " + guestName + " ' is: " + roomNumber);
                    } else {
                        System.out.println("Reservation not found for the given ID and guest name.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error getting room number: " + e.getMessage());
        }
    }
//update reserv wrt id
    private static void updateReservation(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter reservation ID to update: ");
            int reservationId = scanner.nextInt();
            scanner.nextLine(); 

            if (!reservationExists(connection, reservationId)) {
                System.out.println("Reservation not found for the given ID.");
                return;
            }

            System.out.print("Enter new guest name: ");
            String newGuestName = scanner.nextLine();
            System.out.print("Enter new room number: ");
            int newRoomNumber = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter new contact number: ");
            String newContactNumber = scanner.nextLine();

            // Check if the new room is vacant
            String checkSql = "SELECT is_available FROM rooms WHERE room_no = ?";
            boolean roomExists = false;
            boolean isAvailable = false;
            try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
                checkStmt.setInt(1, newRoomNumber);
                ResultSet resultSet = checkStmt.executeQuery();
                if (resultSet.next()) {
                    roomExists = true;
                    isAvailable = resultSet.getBoolean("is_available");
                }
            }

            if (!roomExists) {
                System.out.println("Room number " + newRoomNumber + " does not exist.");
                return;
            }
            if (!isAvailable) {
                System.out.println("Room number " + newRoomNumber + " is already booked. Please choose a different room.");
                return;
            }

            
            String getOldRoomSql = "SELECT room_no FROM reservations WHERE resv_id = ?";
            int oldRoomNumber = 0;
            try (PreparedStatement getOldRoomStmt = connection.prepareStatement(getOldRoomSql)) {
                getOldRoomStmt.setInt(1, reservationId);
                ResultSet resultSet = getOldRoomStmt.executeQuery();
                if (resultSet.next()) {
                    oldRoomNumber = resultSet.getInt("room_no");
                } else {
                    System.out.println("Error: Could not retrieve old room number.");
                    return;
                }
            }

          
            connection.setAutoCommit(false);
            try {
                // Updating reservation
                String sql = "UPDATE reservations SET cust_name = ?, room_no = ?, contact_no = ? WHERE resv_id = ?";
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setString(1, newGuestName);
                    ps.setInt(2, newRoomNumber);
                    ps.setString(3, newContactNumber);
                    ps.setInt(4, reservationId);

                    int affectedRows = ps.executeUpdate();

                    if (affectedRows > 0) 
                    {
                        String updateNewRoomSql = "UPDATE rooms SET is_available = FALSE WHERE room_no = ?";
                        try (PreparedStatement updateNewRoomStmt = connection.prepareStatement(updateNewRoomSql))
                        {
                            updateNewRoomStmt.setInt(1, newRoomNumber);
                            updateNewRoomStmt.executeUpdate();
                        }

                        
                        String deleteOldRoomSql = "DELETE FROM rooms WHERE room_no = ?";
                        try (PreparedStatement deleteOldRoomStmt = connection.prepareStatement(deleteOldRoomSql))
                        {
                            deleteOldRoomStmt.setInt(1, oldRoomNumber);
                            int roomAffectedRows = deleteOldRoomStmt.executeUpdate();
                            if (roomAffectedRows == 0) 
                            {
                                System.out.println("Warning: Old room " + oldRoomNumber + " could not be deleted.");
                            }
                        }

                        System.out.println("Reservation updated successfully!");
                        connection.commit();
                    } else {
                        System.out.println("Reservation update failed.");
                        connection.rollback();
                    }
                }
            } catch (SQLException e) {
                connection.rollback();
                if (e.getMessage().contains("foreign key constraint")) {
                    System.out.println("Cannot delete old room due to existing reservations.");
                } else {
                    System.out.println("Error updating reservation: " + e.getMessage());
                }
            } finally
            {
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error in updateReservation: " + e.getMessage());
        }
    }

    private static void deleteReservation(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter reservation ID to delete: ");
            int reservationId = scanner.nextInt();
            scanner.nextLine(); 

            if (!reservationExists(connection, reservationId)) {
                System.out.println("Reservation not found for the given ID.");
                return;
            }

            String getRoomSql = "SELECT room_no FROM reservations WHERE resv_id = ?";
            int roomNumber = 0;
            try (PreparedStatement getRoomStmt = connection.prepareStatement(getRoomSql)) {
                getRoomStmt.setInt(1, reservationId);
                ResultSet resultSet = getRoomStmt.executeQuery();
                if (resultSet.next()) {
                    roomNumber = resultSet.getInt("room_no");
                } else {
                    System.out.println("Error: Could not retrieve room number.");
                    return;
                }
            }

            connection.setAutoCommit(false);
            try {
                String deleteReservationSql = "DELETE FROM reservations WHERE resv_id = ?";
                try (PreparedStatement ps = connection.prepareStatement(deleteReservationSql)) {
                    ps.setInt(1, reservationId);
                    int affectedRows = ps.executeUpdate();

                    if (affectedRows > 0) {
                        String deleteRoomSql = "DELETE FROM rooms WHERE room_no = ?";
                        try (PreparedStatement deleteRoomStmt = connection.prepareStatement(deleteRoomSql)) {
                            deleteRoomStmt.setInt(1, roomNumber);
                            int roomAffectedRows = deleteRoomStmt.executeUpdate();
                            if (roomAffectedRows > 0) {
                                System.out.println("Reservation and room deleted successfully!");
                            } else {
                                System.out.println("Reservation deleted, but failed to delete room.");
                                connection.rollback();
                                return;
                            }
                        }
                    } else {
                        System.out.println("Reservation deletion failed.");
                        connection.rollback();
                        return;
                    }
                }
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                if (e.getMessage().contains("foreign key constraint")) {
                    System.out.println("Cannot delete room due to existing reservations.");
                } else {
                    System.out.println("Error deleting reservation: " + e.getMessage());
                }
                return;
            } finally {
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error in deleteReservation: " + e.getMessage());
        }
    }

    private static void viewRooms(Connection connection) {
        String sql = "SELECT room_no, is_available, type, price FROM rooms";

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet resultSet = ps.executeQuery()) {

            System.out.println("     Current Rooms: ");
            System.out.println(" --------------------------------------------------------------------- ");
            System.out.println("|   Room_no     |    Status       |  Type           |   Price         |");
            System.out.println(" --------------------------------------------------------------------- ");
            while (resultSet.next()) {
                int roomNumber = resultSet.getInt("room_no");
                boolean isAvailable = resultSet.getBoolean("is_available");
                String type = resultSet.getString("type");
                double price = resultSet.getDouble("price");

                System.out.printf("| %-13d | %-15b | %-15s | %-15.2f |\n",
                        roomNumber, isAvailable, type != null ? type : "null", price);
            }

        } catch (SQLException e) {
            System.out.println("Error viewing rooms: " + e.getMessage());
        }
    }


    private static boolean reservationExists(Connection connection, int reservationId) {
        String sql = "SELECT resv_id FROM reservations WHERE resv_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, reservationId);

            try (ResultSet resultSet = ps.executeQuery()) {
                return resultSet.next();
            }
        } catch (SQLException e) {
            System.out.println("Error checking reservation existence: " + e.getMessage());
            return false;
        }
    }

    public static void exit() throws InterruptedException
    {
        System.out.println ("Exiting reservation process  in ");
        int i = 3;
        while (i != 0) {
            System.out.println(i+"...");
            Thread.sleep(800);
            i--;
        }
        System.out.println();
        System.out.println("Thanks for Choosing Trident Hotel !!!");
    }
}