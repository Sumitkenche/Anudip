create database HotelMngSys;




use HotelMngSys;



-- reservation table for hotel reservation data


create table reservations(
resv_id int auto_increment primary key,
cust_name varchar(200) not null,
room_no  int not null,
contact_no varchar(10) not null,
resv_date timestamp default current_timestamp);

select * from reservations;
select * from reservations;

-- records of rooms if they are available ,their type

CREATE TABLE rooms (
    room_no INT PRIMARY KEY,
    type VARCHAR(50) ,
    is_available BOOLEAN DEFAULT TRUE
);


alter table rooms modify column price int default 1500;-- default price for standard rooms
alter table rooms modify column type varchar(50) default "standard";-- rooms are standard by default





INSERT INTO rooms (room_no, type, price)
VALUES
-- 1st floor
(101, 'Standard', 1500), (102, 'Standard', 1500), (103, 'Standard', 1500), (104, 'Standard', 1500), (105, 'Standard', 1500),
(106, 'Standard', 1500), (107, 'Standard', 1500), (108, 'Standard', 1500), (109, 'Standard', 1500), (110, 'Standard', 1500),

-- 2nd floor
(201, 'Standard', 1500), (202, 'Standard', 1500), (203, 'Standard', 1500), (204, 'Standard', 1500), (205, 'Standard', 1500),
(206, 'Standard', 1500), (207, 'Standard', 1500), (208, 'Standard', 1500), (209, 'Standard', 1500), (210, 'Standard', 1500),

-- 3rd flooor
(301, 'Standard', 1500), (302, 'Standard', 1500), (303, 'Standard', 1500), (304, 'Standard', 1500), (305, 'Standard', 1500),
(306, 'Standard', 1500), (307, 'Standard', 1500), (308, 'Standard', 1500), (309, 'Standard', 1500), (310, 'Standard', 1500),

-- 4th floor
(401, 'Standard', 1500), (402, 'Standard', 1500), (403, 'Standard', 1500), (404, 'Standard', 1500), (405, 'Standard', 1500),
(406, 'Standard', 1500), (407, 'Standard', 1500), (408, 'Standard', 1500), (409, 'Standard', 1500), (410, 'Standard', 1500),

-- Cruise rooms
(111, 'Cruise', 4500), (211, 'Cruise', 4500), (311, 'Cruise', 4500), (411, 'Cruise', 4500);





-- regular required query to update data
select * from rooms;

update room set type="cruise" and price=4500 where room_no=333;-- only for cruise rooms

update rooms set is_available=true where room_no= 301;-- if records gives error

select * from rooms where room_no=101; -- check if room available